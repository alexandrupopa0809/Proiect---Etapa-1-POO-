package com.Heroes;

public class HeroInfo {
    char heroName;
    int rowPos;
    int colPos;

    public HeroInfo(char heroName, int rowPos, int colPos) {
        this.heroName = heroName;
        this.rowPos = rowPos;
        this.colPos = colPos;
    }

}
